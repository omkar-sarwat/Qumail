import React, { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import {
  Reply,
  ReplyAll,
  Forward,
  Trash2,
  Archive,
  Printer,
  Ban,
  MoreHorizontal,
  ShieldAlert,
  Lock,
  ShieldCheck,
  Cpu,
  X,
  ImageIcon,
  CheckCircle2,
} from 'lucide-react';
import SecurityDetails from './SecurityDetails';
import { QuantumEmailViewer } from '../email/QuantumEmailViewer';

// Simplified Email type for UI purposes
interface Email {
  id: string;
  email_id?: string;
  flow_id?: string;
  subject?: string;
  senderName?: string;
  senderEmail?: string;
  senderAvatar?: string;
  timestamp?: string;
  fullDate?: string;
  isEncrypted?: boolean;
  isDecrypted?: boolean;
  securityLevel?: number;
  security_level?: number;
  securityDetails?: any;
  content?: string;
  isStarred?: boolean;
  isUnread?: boolean;
  tags?: string[];
  isRead?: boolean;
  snippet?: string;
  attachments?: any[];
  hashSequence?: string;
  decryptProgress?: number;
  body?: string;
  bodyHtml?: string;
  body_encrypted?: string;
  requires_decryption?: boolean;
  decrypt_endpoint?: string;
  security_info?: {
    level?: number;
    algorithm?: string;
    quantum_enhanced?: boolean;
    encrypted_size?: number;
  };
}

interface EmailViewerProps {
  email: Email | null;
  onReply: () => void;
  onReplyAll: () => void;
  onForward: () => void;
  onDelete: () => void;
  onStar?: (starred: boolean) => void;
  onEmailDecrypted?: (payload: { email_data: any; security_info?: any }) => void;
}

const IconButtonWithTooltip = ({ icon: Icon, label, onClick }: { icon: any; label: string; onClick?: () => void }) => (
  <button
    onClick={onClick}
    className="group relative p-2 hover:bg-gray-100 rounded-lg text-gray-500 transition-colors"
  >
    <Icon size={18} />
    <span className="absolute top-full mt-2 left-1/2 -translate-x-1/2 bg-gray-800 text-white text-[10px] px-2 py-1 rounded opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50 whitespace-nowrap">
      {label}
    </span>
  </button>
);

export const EmailViewer: React.FC<EmailViewerProps> = ({
  email,
  onReply,
  onReplyAll,
  onForward,
  onDelete,
  onStar,
  onEmailDecrypted,
}) => {
  const [isStarred, setIsStarred] = useState(email?.isStarred ?? false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  // Close more menu on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setShowMoreMenu(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const toggleStar = () => {
    const newVal = !isStarred;
    setIsStarred(newVal);
    onStar?.(newVal);
  };

  const normalizedSecurityLevel = useMemo(() => {
    if (!email) return 0;
    return (
      email.securityLevel ??
      email.security_level ??
      email.security_info?.level ??
      0
    );
  }, [email]);

  const isQuantumEmail = useMemo(() => {
    if (!email) return false;
    const hasEncryptedPayload = typeof email.body_encrypted === 'string' && email.body_encrypted.trim().length > 0;
    const explicitFlag = Boolean(email.requires_decryption);
    const hasFlow = Boolean(email.flow_id);
    const decryptEndpoint = Boolean(email.decrypt_endpoint);
    const hasQuantumTag = Array.isArray(email.tags)
      ? email.tags.some(tag => tag?.toUpperCase().includes('QUANTUM'))
      : false;
    return (
      hasEncryptedPayload ||
      explicitFlag ||
      hasFlow ||
      decryptEndpoint ||
      normalizedSecurityLevel > 0 ||
      hasQuantumTag
    );
  }, [email, normalizedSecurityLevel]);

  if (!email) {
    return (
      <div className="flex-1 flex items-center justify-center text-gray-500">Select an email to view</div>
    );
  }

  if (isQuantumEmail) {
    const quantumEmail = {
      email_id: email.email_id ?? email.id,
      flow_id: email.flow_id ?? '',
      sender_email: email.senderEmail ?? '',
      receiver_email: 'me',
      subject: email.subject ?? '(No Subject)',
      body_encrypted: email.body_encrypted ?? '',
      security_level: normalizedSecurityLevel,
      timestamp: email.timestamp ?? new Date().toISOString(),
      is_read: Boolean(email.isRead),
      is_starred: Boolean(email.isStarred),
      requires_decryption: true,
      decrypt_endpoint: email.decrypt_endpoint ?? `/api/v1/emails/email/${email.email_id ?? email.id}/decrypt`,
      security_info: email.security_info ?? {
        level: normalizedSecurityLevel,
        algorithm: email.security_info?.algorithm ?? 'Unknown',
        quantum_enhanced: email.security_info?.quantum_enhanced ?? true,
        encrypted_size: email.security_info?.encrypted_size ?? (email.body_encrypted?.length ?? 0),
      },
      encryption_metadata: email.security_info,
    };

    return (
      <QuantumEmailViewer
        email={quantumEmail}
        onDecrypted={(result) => onEmailDecrypted?.(result)}
      />
    );
  }

  return (
    <div className="flex-1 h-full flex flex-col bg-white rounded-lg shadow-sm border border-gray-200 overflow-hidden relative">
      {/* Sticky Toolbar */}
      <div className="px-6 py-3 border-b border-gray-100 flex items-center justify-between bg-white flex-shrink-0 sticky top-0 z-20">
        <div className="flex items-center gap-1">
          <IconButtonWithTooltip icon={Archive} label="Archive" onClick={onReply} />
          <IconButtonWithTooltip icon={Trash2} label="Delete" onClick={onDelete} />
          <IconButtonWithTooltip icon={Ban} label="Spam" onClick={onDelete} />
          <div className="w-px h-5 bg-gray-200 mx-2" />
          <IconButtonWithTooltip icon={Printer} label="Print" />
          <div className="relative" ref={menuRef}>
            <IconButtonWithTooltip
              icon={MoreHorizontal}
              label="More"
              onClick={() => setShowMoreMenu(!showMoreMenu)}
            />
            {showMoreMenu && (
              <div className="absolute left-0 top-full mt-1 w-48 bg-white rounded-lg shadow-xl border border-gray-200 z-50 py-1 animate-in fade-in zoom-in-95 duration-100 origin-top-left">
                <button className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors" onClick={() => setShowMoreMenu(false)}>
                  <Reply size={14} className="text-gray-400" /> Reply
                </button>
                <button className="w-full text-left px-4 py-2.5 text-sm text-gray-700 hover:bg-gray-50 flex items-center gap-3 transition-colors" onClick={() => setShowMoreMenu(false)}>
                  <Forward size={14} className="text-gray-400" /> Forward
                </button>
              </div>
            )}
          </div>
          {email.securityLevel && (
            <div
              className={`px-3 py-1 rounded-full text-xs font-medium flex items-center gap-2 cursor-help
                ${email.securityLevel === 1 ? 'bg-purple-100 text-purple-700' :
                  email.securityLevel === 2 ? 'bg-indigo-100 text-indigo-700' :
                    'bg-gray-100 text-gray-600'}`}
              title="Encryption Level"
            >
              <ShieldAlert size={14} />
              {email.securityLevel}
            </div>
          )}
        </div>
        <button
          onClick={toggleStar}
          className={`p-2 rounded-full transition-colors ${isStarred ? 'text-yellow-400' : 'text-gray-400 hover:text-yellow-400'}`}
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            viewBox="0 0 24 24"
            fill={isStarred ? 'currentColor' : 'none'}
            stroke="currentColor"
            className="w-5 h-5"
          >
            <path d="M12 17.27L18.18 21l-1.64-7.03L22 9.24l-7.19-.61L12 2 9.19 8.63 2 9.24l5.46 4.73L5.82 21z" />
          </svg>
        </button>
      </div>

      {/* Email Header */}
      <div className="p-8 border-b border-gray-100">
        <h1 className="text-2xl font-bold text-gray-900 mb-6">{email.subject ?? '(No Subject)'}</h1>
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-4">
            <div
              className={`w-10 h-10 rounded-lg flex items-center justify-center text-lg font-bold text-white shadow-sm
                ${email.senderName === 'Google Security' ? 'bg-blue-600' :
                  email.senderName === 'QKD System' ? 'bg-purple-600' :
                    email.senderName === 'MongoDB Atlas' ? 'bg-emerald-600' :
                      email.senderName === 'Render' ? 'bg-gray-900' : 'bg-gray-600'}`}
            >
              {typeof email.senderAvatar === 'string' && email.senderAvatar.length <= 2
                ? email.senderAvatar
                : email.senderName?.[0] ?? '?'}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-gray-900">{email.senderName}</span>
                <span className="text-sm text-gray-500">&lt;{email.senderEmail}&gt;</span>
              </div>
              <p className="text-xs text-gray-500 mt-0.5">To: Me</p>
            </div>
          </div>
          <div className="text-right">
            <p className="text-sm font-medium text-gray-900">{email.fullDate}</p>
            <p className="text-xs text-gray-500">{email.timestamp}</p>
          </div>
        </div>
      </div>

      {/* Email Body */}
      <div className="flex-1 overflow-y-auto p-8">
        {email.isEncrypted && !email.isDecrypted ? (
          <div className="relative m-8 bg-gray-50/50 rounded-lg border border-gray-200 flex flex-col items-center justify-center overflow-hidden shadow-inner">
            <div
              className="absolute inset-0 opacity-[0.03]"
              style={{
                backgroundImage:
                  'linear-gradient(#4f46e5 1px, transparent 1px), linear-gradient(90deg, #4f46e5 1px, transparent 1px)',
                backgroundSize: '20px 20px',
              }}
            />
            <div className="absolute inset-0 bg-gradient-to-b from-transparent via-white/40 to-white/80" />
            <div className="w-full max-w-xs relative z-10 text-center">
              <div className="relative w-16 h-16 mx-auto mb-6">
                <div className="absolute inset-0 bg-indigo-100 rounded-full animate-ping" />
                <div className="relative bg-white rounded-full w-16 h-16 flex items-center justify-center border border-indigo-100 shadow-sm">
                  <Cpu size={32} className="text-indigo-600 animate-pulse" />
                </div>
              </div>
              <h2 className="text-indigo-900 font-bold text-sm tracking-wider mb-2">ESTABLISHING SECURE LINK</h2>
              <div className="font-mono text-[10px] text-indigo-600/60 h-4 mb-4 tracking-widest">{email.hashSequence ?? ''}</div>
              <div className="h-1.5 bg-gray-200 rounded-full overflow-hidden w-full">
                <div
                  className="h-full bg-indigo-600 shadow-[0_0_8px_rgba(79,70,229,0.4)] transition-all duration-75 ease-out"
                  style={{ width: `${email.decryptProgress ?? 0}%` }}
                />
              </div>
              <button
                onClick={onReply}
                className="group bg-indigo-600 text-white hover:bg-indigo-700 px-6 py-2.5 rounded-lg text-sm font-bold shadow-lg shadow-indigo-200 hover:shadow-indigo-300 transition-all flex items-center gap-2 mx-auto mt-4"
              >
                <span>Decrypt Message</span>
                <ShieldCheck size={16} className="text-indigo-200 group-hover:text-white group-hover:scale-110 transition-all" />
              </button>
            </div>
          </div>
        ) : (
          <div className="prose max-w-none flex-1 flex flex-col" dangerouslySetInnerHTML={{ __html: email.content ?? '' }} />
        )}
      </div>

      {/* Security Details */}
      {email.securityDetails && <SecurityDetails email={email} />}

      {/* Action Buttons */}
      <div className="px-6 py-4 border-t border-gray-100 flex gap-3 justify-end">
        <button className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 text-sm font-medium hover:bg-gray-50 hover:text-gray-900 hover:border-gray-300 flex items-center gap-2 transition-all shadow-sm hover:shadow" onClick={onReply}>
          <Reply size={16} /> Reply
        </button>
        <button className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 text-sm font-medium hover:bg-gray-50 hover:text-gray-900 hover:border-gray-300 flex items-center gap-2 transition-all shadow-sm hover:shadow" onClick={onReplyAll}>
          <ReplyAll size={16} /> Reply All
        </button>
        <button className="px-4 py-2 rounded-lg border border-gray-200 text-gray-600 text-sm font-medium hover:bg-gray-50 hover:text-gray-900 hover:border-gray-300 flex items-center gap-2 transition-all shadow-sm hover:shadow" onClick={onForward}>
          <Forward size={16} /> Forward
        </button>
      </div>
    </div>
  );
};

export default EmailViewer;
