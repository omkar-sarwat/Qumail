import React from 'react';
import { Lock, Star, Zap } from 'lucide-react';

interface Email {
  id: string;
  sender_name?: string;
  senderName?: string;
  senderAvatar?: string;
  timestamp: string;
  subject: string;
  snippet: string;
  isUnread?: boolean;
  isStarred?: boolean;
  tags?: string[];
  encrypted?: boolean;
  isEncrypted?: boolean;
  security_level?: number;
  securityLevel?: number;
}

interface EmailListProps {
  emails: Email[];
  selectedEmail: Email | null;
  onEmailSelect: (email: Email) => void;
  onToggleStar: (id: string) => void;
  isLoading: boolean;
  activeFolder: string;
}

export const EmailList: React.FC<EmailListProps> = ({ emails, selectedEmail, onEmailSelect, onToggleStar, isLoading, activeFolder }) => {
  const selectedId = selectedEmail?.id ?? null;

  const formatTimestamp = (value: string) => {
    if (!value) return '';
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return value;

    const now = new Date();
    const isSameDay = date.toDateString() === now.toDateString();
    const isSameYear = date.getFullYear() === now.getFullYear();

    const options: Intl.DateTimeFormatOptions = isSameDay
      ? { hour: '2-digit', minute: '2-digit' }
      : isSameYear
        ? { month: 'short', day: 'numeric' }
        : { month: 'short', day: 'numeric', year: 'numeric' };

    return date.toLocaleString(undefined, options);
  };

  const handleSelect = (id: string) => {
    const email = emails.find((e) => e.id === id);
    if (email) onEmailSelect(email);
  };

  if (isLoading) {
    return (
      <div className="h-full flex flex-col bg-white rounded-lg border border-gray-200 shadow-sm overflow-hidden">
        {/* Header placeholder */}
        <div className="h-14 px-5 border-b border-gray-200 bg-white flex items-center justify-between flex-shrink-0 sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <h2 className="font-bold text-gray-900 text-base capitalize">{activeFolder}</h2>
            <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs font-bold">{emails.length}</span>
          </div>
        </div>
        {/* Loading skeleton */}
        <div className="flex-1 p-4 animate-pulse">
          <div className="h-4 bg-gray-200 rounded w-3/4 mb-2" />
          <div className="h-4 bg-gray-200 rounded w-1/2" />
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full w-[28rem] bg-white flex-shrink-0 z-0 rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
      {/* Header */}
      <div className="h-14 px-5 border-b border-gray-200 bg-white flex items-center justify-between flex-shrink-0 sticky top-0 z-10">
        <div className="flex items-center gap-2">
          <h2 className="font-bold text-gray-900 text-base capitalize">{activeFolder}</h2>
          <span className="bg-gray-100 text-gray-600 px-2 py-0.5 rounded-full text-xs font-bold">{emails.length}</span>
        </div>
      </div>

      {/* List Container */}
      <div className="flex-1 overflow-y-auto bg-white">
        {emails.map((email) => {
          const isSelected = selectedId === email.id;
          const senderName = email.sender_name || email.senderName || 'Unknown Sender';
          const isEncrypted = email.isEncrypted ?? email.encrypted ?? false;
          return (
            <div
              key={email.id}
              onClick={() => handleSelect(email.id)}
              className={`relative py-4 px-4 border-b border-gray-100 cursor-pointer transition-colors duration-150 group flex gap-3 ${isSelected ? 'bg-indigo-50/60' : 'hover:bg-gray-50'
                }`}
            >
              {/* Selection Accent Line */}
              {isSelected && <div className="absolute left-0 top-0 bottom-0 w-1 bg-indigo-600" />}

              {/* Avatar */}
              <div
                className={`w-10 h-10 rounded-lg flex items-center justify-center text-sm font-bold text-white shadow-sm flex-shrink-0 mt-0.5 ${
                  senderName === 'Google Security'
                    ? 'bg-blue-600'
                    : senderName === 'QKD System'
                      ? 'bg-purple-600'
                      : senderName === 'MongoDB' || senderName === 'MongoDB Atlas'
                        ? 'bg-emerald-600'
                        : senderName === 'Render'
                          ? 'bg-gray-900'
                          : senderName === 'GitHub'
                            ? 'bg-gray-800'
                            : 'bg-gray-400'
                }`}
              >
                {email.senderAvatar ?? senderName?.[0] ?? '?'}
              </div>

              {/* Content Column */}
              <div className="min-w-0 overflow-hidden flex-1">
                {/* Row 1: Sender & Time */}
                <div className="flex justify-between items-baseline mb-0.5">
                  <span className={`text-[15px] truncate pr-2 ${email.isUnread ? 'font-bold text-gray-900' : 'font-bold text-gray-700'}`}>
                    {senderName}
                  </span>
                  <span className={`text-xs whitespace-nowrap ${isSelected ? 'text-indigo-600 font-medium' : 'text-gray-400'}`}>
                    {formatTimestamp(email.timestamp)}
                  </span>
                </div>

                {/* Row 2: Subject */}
                <div className="flex items-center gap-1.5 mb-0.5">
                  {isEncrypted && (
                    <Lock size={12} className="text-indigo-500 flex-shrink-0" strokeWidth={2.5} />
                  )}
                  <h4 className={`text-[15px] truncate leading-tight ${email.isUnread ? 'font-semibold text-gray-900' : 'font-medium text-gray-800'}`}>
                    {email.subject}
                  </h4>
                </div>

                {/* Row 3: Snippet */}
                <div className="flex justify-between items-start">
                  <p className="text-[13px] text-gray-500 truncate leading-relaxed max-w-[90%]">{email.snippet}</p>
                  {/* Star Button */}
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onToggleStar(email.id);
                    }}
                    className={`ml-1 p-0.5 rounded transition-all hover:scale-110 ${email.isStarred
                        ? 'text-yellow-400 opacity-100'
                        : `text-gray-300 hover:text-yellow-400 ${isSelected ? 'opacity-100' : 'opacity-0 group-hover:opacity-100'}`
                      }`}
                  >
                    <Star size={16} fill={email.isStarred ? 'currentColor' : 'none'} />
                  </button>
                </div>

                {/* Tags */}
                {(() => {
                  const level = email.security_level ?? email.securityLevel ?? 0;
                  const baseTags = (email.tags || []).filter((tag) => tag !== 'STD');
                  const hasQuantumTag = baseTags.includes('QUANTUM');
                  const shouldShowQuantum = level >= 1 && level <= 4;

                  const visibleTags = shouldShowQuantum
                    ? hasQuantumTag
                      ? baseTags
                      : ['QUANTUM', ...baseTags]
                    : baseTags.filter((tag) => tag !== 'QUANTUM');

                  if (!visibleTags.length) return null;

                  return (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {visibleTags.map((tag) => {
                        const isQuantum = tag === 'QUANTUM';
                        return (
                          <span
                            key={tag}
                            className={`text-[10px] px-2 py-0.5 rounded-full border flex items-center gap-1 font-bold tracking-wide transition-all ${isQuantum
                                ? 'bg-emerald-50 text-emerald-700 border-emerald-200 hover:border-emerald-300'
                                : 'bg-white text-gray-500 border-gray-200'
                              }`}
                          >
                            {isQuantum && <Zap size={10} className="text-emerald-600 fill-emerald-100" />}
                            {tag}
                          </span>
                        );
                      })}
                    </div>
                  );
                })()}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default EmailList;