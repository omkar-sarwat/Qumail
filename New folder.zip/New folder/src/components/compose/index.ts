// Export both compose modal versions
export { ComposeEmailModal } from './ComposeEmailModal'
export { NewComposeEmailModal } from './NewComposeEmailModal'
export type { QuantumSendSummary } from './ComposeEmailModal'
