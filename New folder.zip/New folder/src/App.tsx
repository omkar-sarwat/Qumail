import React, { useState } from 'react'
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { LoginScreen } from './components/auth/LoginScreen'
import { OAuthCallback } from './components/auth/OAuthCallback'
import { MainDashboard } from './components/dashboard/MainDashboard'
import { AuthProvider, useAuth } from './context/AuthContext'
import { TitleBar } from './components/TitleBar'
import SplashScreen from './components/SplashScreen'

// Inner component that uses auth context
const AppContent: React.FC = () => {
  const { isAuthenticated, isLoading } = useAuth()
  const [showSplash, setShowSplash] = useState(true)

  return (
    <div className="h-screen overflow-hidden flex flex-col">
      {showSplash && <SplashScreen onFinish={() => setShowSplash(false)} />}
      {window.electronAPI && <TitleBar />}
      <div className="flex-1 overflow-hidden flex flex-col">
        {isLoading ? (
          <div className="min-h-full bg-gray-50 flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-xl font-semibold text-gray-900 mb-2">
                Initializing QuMail
              </h2>
              <p className="text-gray-500">
                Checking quantum security status...
              </p>
            </div>
          </div>
        ) : (
          <Routes>
            <Route
              path="/auth/callback"
              element={<OAuthCallback onAuthComplete={() => {
                // OAuthCallback component will use the auth context directly
                // No need to handle it here
              }} />}
            />
            <Route
              path="/dashboard"
              element={
                isAuthenticated ? (
                  <MainDashboard />
                ) : (
                  <Navigate to="/" replace />
                )
              }
            />
            <Route
              path="/"
              element={
                isAuthenticated ? (
                  <Navigate to="/dashboard" replace />
                ) : (
                  <LoginScreen />
                )
              }
            />
            <Route
              path="*"
              element={<Navigate to="/" replace />}
            />
          </Routes>
        )}

        {/* Toast notifications */}
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#1e293b',
              color: '#f1f5f9',
              border: '1px solid #334155',
              borderRadius: '12px',
              fontSize: '14px',
              fontWeight: '500',
              padding: '12px 16px',
              boxShadow: '0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05)',
            },
            success: {
              iconTheme: {
                primary: '#10b981',
                secondary: '#ffffff',
              },
            },
            error: {
              iconTheme: {
                primary: '#ef4444',
                secondary: '#ffffff',
              },
            },
          }}
        />
      </div>
    </div>
  )
}

const App: React.FC = () => {
  return (
    <Router>
      <AuthProvider>
        <AppContent />
      </AuthProvider>
    </Router>
  )
}

export default App