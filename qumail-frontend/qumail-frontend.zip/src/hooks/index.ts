// Hooks barrel file for easy imports
export { useConnectionStatus, useAppVisibility, useWindowFocus } from './useConnectionStatus';
