"use strict";
// SQLite-based persistent database for Electron using sql.js (pure JS, no native build)
// Data survives app restarts
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.initDatabaseAsync = initDatabaseAsync;
exports.initDatabase = initDatabase;
exports.closeDatabase = closeDatabase;
exports.getEmails = getEmails;
exports.getEmailById = getEmailById;
exports.getEmailByFlowId = getEmailByFlowId;
exports.saveEmail = saveEmail;
exports.saveEmails = saveEmails;
exports.updateEmailStatus = updateEmailStatus;
exports.deleteEmail = deleteEmail;
exports.getEmailCounts = getEmailCounts;
exports.getUnreadCounts = getUnreadCounts;
exports.searchEmails = searchEmails;
exports.addToSyncQueue = addToSyncQueue;
exports.getPendingSyncItems = getPendingSyncItems;
exports.completeSyncItem = completeSyncItem;
exports.failSyncItem = failSyncItem;
exports.getSyncQueueCount = getSyncQueueCount;
exports.getCachedDecryption = getCachedDecryption;
exports.cacheDecryptedContent = cacheDecryptedContent;
exports.getSetting = getSetting;
exports.setSetting = setSetting;
exports.getLastSyncTime = getLastSyncTime;
exports.setLastSyncTime = setLastSyncTime;
exports.getDatabaseStats = getDatabaseStats;
exports.clearAllData = clearAllData;
var sql_js_1 = __importDefault(require("sql.js"));
var electron_1 = require("electron");
var path_1 = __importDefault(require("path"));
var fs_1 = __importDefault(require("fs"));
var db = null;
var dbPath = '';
var saveTimeout = null;
// Debounced save to disk
function scheduleSave() {
    if (saveTimeout)
        clearTimeout(saveTimeout);
    saveTimeout = setTimeout(function () {
        if (db && dbPath) {
            try {
                var data = db.export();
                fs_1.default.writeFileSync(dbPath, Buffer.from(data));
                console.log('[Database] Saved to disk');
            }
            catch (e) {
                console.error('[Database] Failed to save:', e);
            }
        }
    }, 1000); // Save after 1 second of no changes
}
// Initialize database with sql.js
function initDatabaseAsync() {
    return __awaiter(this, void 0, void 0, function () {
        var userDataPath, SQL, fileBuffer;
        return __generator(this, function (_a) {
            switch (_a.label) {
                case 0:
                    userDataPath = electron_1.app.getPath('userData');
                    dbPath = path_1.default.join(userDataPath, 'qumail.db');
                    console.log('[Database] Opening sql.js database at:', dbPath);
                    return [4 /*yield*/, (0, sql_js_1.default)()
                        // Try to load existing database
                    ];
                case 1:
                    SQL = _a.sent();
                    // Try to load existing database
                    if (fs_1.default.existsSync(dbPath)) {
                        try {
                            fileBuffer = fs_1.default.readFileSync(dbPath);
                            db = new SQL.Database(fileBuffer);
                            console.log('[Database] Loaded existing database');
                        }
                        catch (e) {
                            console.warn('[Database] Failed to load existing db, creating new:', e);
                            db = new SQL.Database();
                        }
                    }
                    else {
                        db = new SQL.Database();
                    }
                    // Create tables
                    db.run("\n    CREATE TABLE IF NOT EXISTS emails (\n      id TEXT PRIMARY KEY,\n      thread_id TEXT,\n      gmail_message_id TEXT,\n      subject TEXT,\n      sender_email TEXT,\n      sender_name TEXT,\n      recipient_email TEXT,\n      body TEXT,\n      body_html TEXT,\n      body_encrypted TEXT,\n      snippet TEXT,\n      folder TEXT DEFAULT 'inbox',\n      is_read INTEGER DEFAULT 0,\n      is_starred INTEGER DEFAULT 0,\n      is_encrypted INTEGER DEFAULT 0,\n      is_decrypted INTEGER DEFAULT 0,\n      globally_decrypted INTEGER DEFAULT 0,\n      security_level INTEGER,\n      flow_id TEXT,\n      algorithm TEXT,\n      quantum_enhanced INTEGER DEFAULT 0,\n      decrypted_content TEXT,\n      decrypted_html TEXT,\n      security_info TEXT,\n      encryption_metadata TEXT,\n      attachments TEXT,\n      timestamp TEXT,\n      synced_at TEXT,\n      last_modified TEXT,\n      sync_status TEXT DEFAULT 'synced'\n    )\n  ");
                    db.run("\n    CREATE TABLE IF NOT EXISTS sync_queue (\n      id INTEGER PRIMARY KEY AUTOINCREMENT,\n      operation TEXT,\n      email_id TEXT,\n      data TEXT,\n      created_at TEXT,\n      attempts INTEGER DEFAULT 0,\n      last_error TEXT\n    )\n  ");
                    db.run("\n    CREATE TABLE IF NOT EXISTS decryption_cache (\n      email_id TEXT PRIMARY KEY,\n      flow_id TEXT,\n      decrypted_body TEXT,\n      decrypted_html TEXT,\n      security_info TEXT,\n      cached_at TEXT\n    )\n  ");
                    db.run("\n    CREATE TABLE IF NOT EXISTS settings (\n      key TEXT PRIMARY KEY,\n      value TEXT\n    )\n  ");
                    db.run("CREATE INDEX IF NOT EXISTS idx_emails_folder ON emails(folder)");
                    db.run("CREATE INDEX IF NOT EXISTS idx_emails_timestamp ON emails(timestamp)");
                    db.run("CREATE INDEX IF NOT EXISTS idx_emails_flow_id ON emails(flow_id)");
                    scheduleSave();
                    console.log('[Database] sql.js database initialized');
                    return [2 /*return*/];
            }
        });
    });
}
// Sync init wrapper for backward compatibility
function initDatabase() {
    initDatabaseAsync().catch(function (e) { return console.error('[Database] Init failed:', e); });
}
// Close database
function closeDatabase() {
    if (saveTimeout) {
        clearTimeout(saveTimeout);
        saveTimeout = null;
    }
    if (db && dbPath) {
        try {
            var data = db.export();
            fs_1.default.writeFileSync(dbPath, Buffer.from(data));
            console.log('[Database] Final save on close');
        }
        catch (e) {
            console.error('[Database] Failed to save on close:', e);
        }
        db.close();
        db = null;
        console.log('[Database] sql.js database closed');
    }
}
// Helper to convert query result to array of objects
function queryToObjects(stmt) {
    var results = [];
    while (stmt.step()) {
        var row = stmt.getAsObject();
        results.push(row);
    }
    stmt.free();
    return results;
}
// Get emails by folder
function getEmails(folder, limit, offset) {
    if (limit === void 0) { limit = 100; }
    if (offset === void 0) { offset = 0; }
    if (!db)
        return [];
    var sql = folder === 'all'
        ? 'SELECT * FROM emails ORDER BY timestamp DESC LIMIT ? OFFSET ?'
        : 'SELECT * FROM emails WHERE folder = ? ORDER BY timestamp DESC LIMIT ? OFFSET ?';
    var stmt = db.prepare(sql);
    if (folder === 'all') {
        stmt.bind([limit, offset]);
    }
    else {
        stmt.bind([folder, limit, offset]);
    }
    return queryToObjects(stmt).map(rowToEmail);
}
// Get email by ID
function getEmailById(id) {
    if (!db)
        return undefined;
    var stmt = db.prepare('SELECT * FROM emails WHERE id = ?');
    stmt.bind([id]);
    var rows = queryToObjects(stmt);
    return rows.length > 0 ? rowToEmail(rows[0]) : undefined;
}
// Get email by flow ID
function getEmailByFlowId(flowId) {
    if (!db)
        return undefined;
    var stmt = db.prepare('SELECT * FROM emails WHERE flow_id = ?');
    stmt.bind([flowId]);
    var rows = queryToObjects(stmt);
    return rows.length > 0 ? rowToEmail(rows[0]) : undefined;
}
// Save single email
function saveEmail(email) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _j, _k, _l, _m, _o, _p, _q, _r;
    if (!db)
        return;
    db.run("\n    INSERT OR REPLACE INTO emails (\n      id, thread_id, gmail_message_id, subject, sender_email, sender_name,\n      recipient_email, body, body_html, body_encrypted, snippet, folder,\n      is_read, is_starred, is_encrypted, is_decrypted, globally_decrypted,\n      security_level, flow_id, algorithm, quantum_enhanced, decrypted_content,\n      decrypted_html, security_info, encryption_metadata, attachments,\n      timestamp, synced_at, last_modified, sync_status\n    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)\n  ", [
        email.id,
        (_a = email.thread_id) !== null && _a !== void 0 ? _a : null,
        (_b = email.gmail_message_id) !== null && _b !== void 0 ? _b : null,
        email.subject,
        email.sender_email,
        (_c = email.sender_name) !== null && _c !== void 0 ? _c : null,
        email.recipient_email,
        (_d = email.body) !== null && _d !== void 0 ? _d : null,
        (_e = email.body_html) !== null && _e !== void 0 ? _e : null,
        (_f = email.body_encrypted) !== null && _f !== void 0 ? _f : null,
        (_g = email.snippet) !== null && _g !== void 0 ? _g : null,
        email.folder, email.is_read ? 1 : 0, email.is_starred ? 1 : 0,
        email.is_encrypted ? 1 : 0, email.is_decrypted ? 1 : 0,
        email.globally_decrypted ? 1 : 0,
        (_h = email.security_level) !== null && _h !== void 0 ? _h : null,
        (_j = email.flow_id) !== null && _j !== void 0 ? _j : null,
        (_k = email.algorithm) !== null && _k !== void 0 ? _k : null,
        email.quantum_enhanced ? 1 : 0,
        (_l = email.decrypted_content) !== null && _l !== void 0 ? _l : null,
        (_m = email.decrypted_html) !== null && _m !== void 0 ? _m : null,
        (_o = email.security_info) !== null && _o !== void 0 ? _o : null,
        (_p = email.encryption_metadata) !== null && _p !== void 0 ? _p : null,
        (_q = email.attachments) !== null && _q !== void 0 ? _q : null,
        email.timestamp,
        (_r = email.synced_at) !== null && _r !== void 0 ? _r : null,
        new Date().toISOString(), email.sync_status
    ]);
    scheduleSave();
}
// Save multiple emails
function saveEmails(emails) {
    if (!db)
        return;
    for (var _i = 0, emails_1 = emails; _i < emails_1.length; _i++) {
        var email = emails_1[_i];
        saveEmail(email);
    }
}
// Update email status
function updateEmailStatus(id, updates) {
    if (!db)
        return;
    var sets = [];
    var values = [];
    for (var _i = 0, _a = Object.entries(updates); _i < _a.length; _i++) {
        var _b = _a[_i], key = _b[0], val = _b[1];
        sets.push("".concat(key, " = ?"));
        values.push(typeof val === 'boolean' ? (val ? 1 : 0) : val);
    }
    sets.push('last_modified = ?');
    values.push(new Date().toISOString());
    values.push(id);
    db.run("UPDATE emails SET ".concat(sets.join(', '), " WHERE id = ?"), values);
    scheduleSave();
}
// Delete email
function deleteEmail(id) {
    if (!db)
        return;
    db.run('DELETE FROM emails WHERE id = ?', [id]);
    scheduleSave();
}
// Get email counts by folder
function getEmailCounts() {
    if (!db)
        return {};
    var stmt = db.prepare('SELECT folder, COUNT(*) as cnt FROM emails GROUP BY folder');
    var rows = queryToObjects(stmt);
    var counts = {};
    for (var _i = 0, rows_1 = rows; _i < rows_1.length; _i++) {
        var r = rows_1[_i];
        counts[r.folder] = r.cnt;
    }
    return counts;
}
// Get unread counts by folder
function getUnreadCounts() {
    if (!db)
        return {};
    var stmt = db.prepare('SELECT folder, COUNT(*) as cnt FROM emails WHERE is_read = 0 GROUP BY folder');
    var rows = queryToObjects(stmt);
    var counts = {};
    for (var _i = 0, rows_2 = rows; _i < rows_2.length; _i++) {
        var r = rows_2[_i];
        counts[r.folder] = r.cnt;
    }
    return counts;
}
// Search emails
function searchEmails(query, folder) {
    if (!db)
        return [];
    var lowerQuery = "%".concat(query.toLowerCase(), "%");
    var sql = folder
        ? 'SELECT * FROM emails WHERE folder = ? AND (LOWER(subject) LIKE ? OR LOWER(sender_name) LIKE ? OR LOWER(sender_email) LIKE ? OR LOWER(snippet) LIKE ? OR LOWER(body) LIKE ?) ORDER BY timestamp DESC'
        : 'SELECT * FROM emails WHERE (LOWER(subject) LIKE ? OR LOWER(sender_name) LIKE ? OR LOWER(sender_email) LIKE ? OR LOWER(snippet) LIKE ? OR LOWER(body) LIKE ?) ORDER BY timestamp DESC';
    var stmt = db.prepare(sql);
    if (folder) {
        stmt.bind([folder, lowerQuery, lowerQuery, lowerQuery, lowerQuery, lowerQuery]);
    }
    else {
        stmt.bind([lowerQuery, lowerQuery, lowerQuery, lowerQuery, lowerQuery]);
    }
    return queryToObjects(stmt).map(rowToEmail);
}
// Sync queue operations
function addToSyncQueue(operation, emailId, data) {
    if (!db)
        return;
    db.run('INSERT INTO sync_queue (operation, email_id, data, created_at, attempts) VALUES (?, ?, ?, ?, 0)', [operation, emailId, data ? JSON.stringify(data) : null, new Date().toISOString()]);
    scheduleSave();
}
function getPendingSyncItems(limit) {
    if (limit === void 0) { limit = 50; }
    if (!db)
        return [];
    var stmt = db.prepare('SELECT * FROM sync_queue ORDER BY id LIMIT ?');
    stmt.bind([limit]);
    return queryToObjects(stmt);
}
function completeSyncItem(id) {
    if (!db)
        return;
    db.run('DELETE FROM sync_queue WHERE id = ?', [id]);
    scheduleSave();
}
function failSyncItem(id, error) {
    if (!db)
        return;
    db.run('UPDATE sync_queue SET attempts = attempts + 1, last_error = ? WHERE id = ?', [error, id]);
    scheduleSave();
}
function getSyncQueueCount() {
    var _a, _b;
    if (!db)
        return 0;
    var stmt = db.prepare('SELECT COUNT(*) as cnt FROM sync_queue');
    var rows = queryToObjects(stmt);
    return (_b = (_a = rows[0]) === null || _a === void 0 ? void 0 : _a.cnt) !== null && _b !== void 0 ? _b : 0;
}
// Decryption cache operations
function getCachedDecryption(emailId) {
    if (!db)
        return undefined;
    var stmt = db.prepare('SELECT * FROM decryption_cache WHERE email_id = ?');
    stmt.bind([emailId]);
    var rows = queryToObjects(stmt);
    return rows.length > 0 ? rows[0] : undefined;
}
function cacheDecryptedContent(cache) {
    var _a, _b;
    if (!db)
        return;
    db.run("\n    INSERT OR REPLACE INTO decryption_cache (email_id, flow_id, decrypted_body, decrypted_html, security_info, cached_at)\n    VALUES (?, ?, ?, ?, ?, ?)\n  ", [cache.email_id, (_a = cache.flow_id) !== null && _a !== void 0 ? _a : null, cache.decrypted_body, (_b = cache.decrypted_html) !== null && _b !== void 0 ? _b : null, cache.security_info, new Date().toISOString()]);
    scheduleSave();
}
// Settings operations
function getSetting(key) {
    var _a;
    if (!db)
        return undefined;
    var stmt = db.prepare('SELECT value FROM settings WHERE key = ?');
    stmt.bind([key]);
    var rows = queryToObjects(stmt);
    return (_a = rows[0]) === null || _a === void 0 ? void 0 : _a.value;
}
function setSetting(key, value) {
    if (!db)
        return;
    db.run('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)', [key, value]);
    scheduleSave();
}
// Sync time operations
function getLastSyncTime() {
    var _a;
    return (_a = getSetting('last_sync')) !== null && _a !== void 0 ? _a : '';
}
function setLastSyncTime(time) {
    setSetting('last_sync', time);
}
// Get database stats
function getDatabaseStats() {
    var _a, _b, _c, _d, _e, _f;
    if (!db)
        return { emails: 0, syncQueue: 0, cacheSize: 0 };
    var emailsStmt = db.prepare('SELECT COUNT(*) as cnt FROM emails');
    var emailsRows = queryToObjects(emailsStmt);
    var syncStmt = db.prepare('SELECT COUNT(*) as cnt FROM sync_queue');
    var syncRows = queryToObjects(syncStmt);
    var cacheStmt = db.prepare('SELECT COUNT(*) as cnt FROM decryption_cache');
    var cacheRows = queryToObjects(cacheStmt);
    return {
        emails: (_b = (_a = emailsRows[0]) === null || _a === void 0 ? void 0 : _a.cnt) !== null && _b !== void 0 ? _b : 0,
        syncQueue: (_d = (_c = syncRows[0]) === null || _c === void 0 ? void 0 : _c.cnt) !== null && _d !== void 0 ? _d : 0,
        cacheSize: (_f = (_e = cacheRows[0]) === null || _e === void 0 ? void 0 : _e.cnt) !== null && _f !== void 0 ? _f : 0
    };
}
// Clear all data
function clearAllData() {
    if (!db)
        return;
    db.run('DELETE FROM emails');
    db.run('DELETE FROM sync_queue');
    db.run('DELETE FROM decryption_cache');
    db.run('DELETE FROM settings');
    scheduleSave();
    console.log('[Database] All data cleared');
}
// Helper: convert row to LocalEmail
function rowToEmail(row) {
    return __assign(__assign({}, row), { is_read: !!row.is_read, is_starred: !!row.is_starred, is_encrypted: !!row.is_encrypted, is_decrypted: !!row.is_decrypted, globally_decrypted: !!row.globally_decrypted, quantum_enhanced: !!row.quantum_enhanced });
}
